<?php
include('db_connection.php');
if (isset($_POST['save'])) {
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$e_id = $_POST['e_id'];
$email = $_POST['mail'];
$phone = $_POST['phone'];
$date = date("Y-m-d");
$j_id = $_POST['j_id'];
$salary = $_POST['salary'];
$commision = $_POST['commision'];
$m_id = $_POST['m_id'];
$d_id = $_POST['d_id'];

 mysqli_query($conn, "INSERT INTO employees(employee_id, first_name, last_name, email, phone_number, hire_date, job_id, salary, commission_pct, manager_id, department_id) VALUES($fname, $lname, $e_id, $email, $phone, $date, $j_id, $salary, $commision, $m_id, $d_id);");
 header('location: first.php');
 }
 ?>